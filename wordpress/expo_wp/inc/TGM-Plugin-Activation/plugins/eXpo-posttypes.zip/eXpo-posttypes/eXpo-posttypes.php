<?php

/**
 * Plugin Name: eXpo's Custom Post Types and Taxonomies
 * Description: A simple plugin that adds custom post types and taxonomies
 * Version: 0.1
 * Author: Brian Yoo
 * License: GPL2
 */



function eXpo_posttypes() {

	// Web Post Types
	$labels = array(
		'name'								=> 'Projects',
		'singular_name'				=> 'Project',
		'menu_name'						=> 'Projects',
		'name_admin_bar'			=> 'Projects',
		'add_new'							=> 'Add New',
		'add_new_item'				=> 'Add New Project',
		'new_item'						=> 'New Project',
		'edit_item'						=> 'Edit Project',
		'view_item'						=> 'View Project',
		'all_items'						=> 'All Projects',
		'search_items'				=> 'Search Projects',
		'parent_item_colon'		=> 'Parent Project:',
		'not_found'						=> 'No project posts found.',
		'not_found_in_trash'	=> 'No projects posts found in Trash.',
	);

	$args = array(
		'labels'							=> $labels,
		'public'							=> true,
		'publicly_queryable'	=> true,
		'show_ui'							=> true,
		'show_in_menu'				=> true,
		'show_in_rest'				=> true,
		'menu_position'				=> 5,
		'menu_icon'						=> 'dashicons-layout',
		'query_var'						=> true,
		'rewrite'							=> array( 'slug' => 'post-projects' ),
		'capability_type'			=> 'post',
		'has_archive'					=> true,
		'hierarchical'				=> false,
		'supports'						=> array( 'title', 'editor', 'thumbnail', 'author', 'excerpt' ),
		'taxonomies'					=> array( 'category', 'post_tag' )
	);

	register_post_type( 'post-projects', $args );

	// Photos Post Types
	$labels = array(
		'name'								=> 'Photography',
		'singular_name'				=> 'Photography',
		'menu_name'						=> 'Photography',
		'name_admin_bar'			=> 'Photography',
		'add_new'							=> 'Add New',
		'add_new_item'				=> 'Add New Photography',
		'new_item'						=> 'New Photography',
		'edit_item'						=> 'Edit Photography',
		'view_item'						=> 'View Photography',
		'all_items'						=> 'All Photography',
		'search_items'				=> 'Search Photography',
		'parent_item_colon'		=> 'Parent Photography:',
		'not_found'						=> 'No photography posts found.',
		'not_found_in_trash'	=> 'No photography posts found in Trash.',
	);

	$args = array(
		'labels'							=> $labels,
		'public'							=> true,
		'publicly_queryable'	=> true,
		'show_ui'							=> true,
		'show_in_menu'				=> true,
		'show_in_rest'				=> true,
		'menu_position'				=> 5,
		'menu_icon'						=> 'dashicons-camera',
		'query_var'						=> true,
		'rewrite'							=> array( 'slug' => 'post-photography' ),
		'capability_type'			=> 'post',
		'has_archive'					=> true,
		'hierarchical'				=> false,
		'supports'						=> array( 'title', 'editor', 'thumbnail', 'author', 'excerpt' ),
		'taxonomies'					=> array( 'category', 'post_tag' )
	);

	register_post_type( 'post-photography', $args );


	// Media Work Post Types
	$labels = array(
		'name'								=> 'Media Work',
		'singular_name'				=> 'Media Work',
		'menu_name'						=> 'Media Work',
		'name_admin_bar'			=> 'Media Work',
		'add_new'							=> 'Add New',
		'add_new_item'				=> 'Add New Media Work',
		'new_item'						=> 'New Media Work',
		'edit_item'						=> 'Edit Media Work',
		'view_item'						=> 'View Media Work',
		'all_items'						=> 'All Media Work',
		'search_items'				=> 'Search Media Work',
		'parent_item_colon'		=> 'Parent Media Work:',
		'not_found'						=> 'No media work post found.',
		'not_found_in_trash'	=> 'No media work posts found in Trash.',
	);

	$args = array(
		'labels'							=> $labels,
		'public'							=> true,
		'publicly_queryable'	=> true,
		'show_ui'							=> true,
		'show_in_menu'				=> true,
		'show_in_rest'				=> true,
		'menu_position'				=> 5,
		'menu_icon'						=> 'dashicons-video-alt2',
		'query_var'						=> true,
		'rewrite'							=> array( 'slug' => 'post-media' ),
		'capability_type'			=> 'post',
		'has_archive'					=> true,
		'hierarchical'				=> false,
		'supports'						=> array( 'title', 'editor', 'thumbnail', 'author', 'excerpt' ),
		'taxonomies'					=> array( 'category', 'post_tag' )
	);

	register_post_type( 'post-media', $args );
}

add_action( 'init', 'eXpo_posttypes' );

function my_rewrite_flush() {
    // First, we "add" the custom post type via the above written function.
    // Note: "add" is written with quotes, as CPTs don't get added to the DB,
    // They are only referenced in the post_type column with a post entry,
    // when you add a post of this CPT.
    eXpo_posttypes();

    // ATTENTION: This is *only* done during plugin activation hook in this example!
    // You should *NEVER EVER* do this on every page load!!
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'my_rewrite_flush' );


?>
